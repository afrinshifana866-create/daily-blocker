package com.example.ui

import android.app.AlarmManager
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppInfo
import com.example.data.model.BlockSchedule
import com.example.data.repository.ScheduleRepository
import com.example.service.AppBlockAccessibilityService
import com.example.service.ScheduleAlarmManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

data class DiagnosticStatus(
    val isAccessibilityEnabled: Boolean,
    val isOverlayPermissionGranted: Boolean,
    val isBatteryOptimizationIgnored: Boolean,
    val canScheduleExactAlarms: Boolean,
    val isFullyOperational: Boolean
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ScheduleRepository.getInstance(application)

    val schedules: StateFlow<List<BlockSchedule>> = repository.allSchedules.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _installedApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val installedApps: StateFlow<List<AppInfo>> = _installedApps.asStateFlow()

    private val _diagnostics = MutableStateFlow(
        DiagnosticStatus(
            isAccessibilityEnabled = false,
            isOverlayPermissionGranted = false,
            isBatteryOptimizationIgnored = false,
            canScheduleExactAlarms = true,
            isFullyOperational = false
        )
    )
    val diagnostics: StateFlow<DiagnosticStatus> = _diagnostics.asStateFlow()

    private val _activeSchedule = MutableStateFlow<BlockSchedule?>(null)
    val activeSchedule: StateFlow<BlockSchedule?> = _activeSchedule.asStateFlow()

    init {
        loadInstalledApps()
        refreshDiagnostics()
        checkCurrentlyActiveSchedule()
    }

    fun refreshDiagnostics() {
        val context = getApplication<Application>()
        val isAccessibility = AppBlockAccessibilityService.isAccessibilityEnabledInSettings(context) ||
                AppBlockAccessibilityService.isServiceRunning.value

        val isOverlay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val isBatteryIgnored = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            powerManager?.isIgnoringBatteryOptimizations(context.packageName) ?: false
        } else {
            true
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
        val canExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager?.canScheduleExactAlarms() ?: true
        } else {
            true
        }

        val isFullyOperational = isAccessibility

        _diagnostics.value = DiagnosticStatus(
            isAccessibilityEnabled = isAccessibility,
            isOverlayPermissionGranted = isOverlay,
            isBatteryOptimizationIgnored = isBatteryIgnored,
            canScheduleExactAlarms = canExact,
            isFullyOperational = isFullyOperational
        )

        checkCurrentlyActiveSchedule()
    }

    fun checkCurrentlyActiveSchedule() {
        viewModelScope.launch(Dispatchers.Default) {
            val now = Calendar.getInstance()
            val list = schedules.value
            val current = list.firstOrNull { it.isEnabled && it.isCurrentlyActive(now) }
            _activeSchedule.value = current
        }
    }

    private fun loadInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val context = getApplication<Application>()
            val pm = context.packageManager
            val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val resolveInfos = pm.queryIntentActivities(launcherIntent, 0)

            val discoveredPackages = mutableSetOf<String>()
            val discoveredApps = mutableListOf<AppInfo>()

            for (resolveInfo in resolveInfos) {
                val pkgName = resolveInfo.activityInfo.packageName
                if (pkgName == context.packageName) continue // Skip our own app

                discoveredPackages.add(pkgName)
                val appLabel = resolveInfo.loadLabel(pm).toString()
                val icon = resolveInfo.loadIcon(pm)

                discoveredApps.add(
                    AppInfo(
                        packageName = pkgName,
                        appName = appLabel,
                        icon = icon,
                        isInstalled = true,
                        category = determineCategory(pkgName, appLabel),
                        isPreset = false
                    )
                )
            }

            // Also integrate popular presets so users can configure Instagram, YouTube, Facebook even if not yet on emulator
            val mergedList = mutableListOf<AppInfo>()

            // Add presets first
            for (preset in AppInfo.PRESET_APPS) {
                val isInstalled = discoveredPackages.contains(preset.packageName)
                val localIcon = if (isInstalled) {
                    try {
                        pm.getApplicationIcon(preset.packageName)
                    } catch (_: Exception) {
                        null
                    }
                } else null

                mergedList.add(
                    preset.copy(
                        isInstalled = isInstalled,
                        icon = localIcon
                    )
                )
            }

            // Add other discovered installed apps
            for (app in discoveredApps) {
                if (AppInfo.PRESET_APPS.none { it.packageName == app.packageName }) {
                    mergedList.add(app)
                }
            }

            mergedList.sortBy { it.appName.lowercase() }
            _installedApps.value = mergedList
        }
    }

    private fun determineCategory(pkg: String, label: String): String {
        val lower = "$pkg $label".lowercase()
        return when {
            lower.contains("instagram") || lower.contains("facebook") || lower.contains("twitter") || lower.contains("reddit") || lower.contains("tiktok") || lower.contains("snapchat") -> "Social"
            lower.contains("youtube") || lower.contains("netflix") || lower.contains("video") || lower.contains("twitch") -> "Video"
            lower.contains("game") || lower.contains("play") || lower.contains("candy") || lower.contains("roblox") -> "Games"
            else -> "Other"
        }
    }

    fun saveSchedule(schedule: BlockSchedule) {
        viewModelScope.launch {
            if (schedule.id == 0L) {
                repository.insertSchedule(schedule)
            } else {
                repository.updateSchedule(schedule)
            }
            ScheduleAlarmManager.rescheduleAll(getApplication())
            checkCurrentlyActiveSchedule()
        }
    }

    fun toggleSchedule(scheduleId: Long, isEnabled: Boolean) {
        viewModelScope.launch {
            repository.toggleScheduleEnabled(scheduleId, isEnabled)
            ScheduleAlarmManager.rescheduleAll(getApplication())
            checkCurrentlyActiveSchedule()
        }
    }

    fun deleteSchedule(scheduleId: Long) {
        viewModelScope.launch {
            repository.deleteById(scheduleId)
            ScheduleAlarmManager.rescheduleAll(getApplication())
            checkCurrentlyActiveSchedule()
        }
    }

    /**
     * Creates an instant 2-minute test schedule starting right now, allowing immediate user testing of app blocking.
     */
    fun createInstantTestSchedule(targetPackage: String = "com.instagram.android", targetAppName: String = "Instagram") {
        viewModelScope.launch {
            val now = Calendar.getInstance()
            val startHour = now.get(Calendar.HOUR_OF_DAY)
            val startMinute = now.get(Calendar.MINUTE)

            val endCal = Calendar.getInstance().apply { add(Calendar.MINUTE, 5) }
            val endHour = endCal.get(Calendar.HOUR_OF_DAY)
            val endMinute = endCal.get(Calendar.MINUTE)

            val testSchedule = BlockSchedule(
                name = "Instant Test Block (5 min)",
                startHour = startHour,
                startMinute = startMinute,
                endHour = endHour,
                endMinute = endMinute,
                daysOfWeek = "1,2,3,4,5,6,7",
                blockedPackages = targetPackage,
                blockedAppNames = targetAppName,
                isEnabled = true,
                strictMode = false
            )

            repository.insertSchedule(testSchedule)
            ScheduleAlarmManager.rescheduleAll(getApplication())
            checkCurrentlyActiveSchedule()
        }
    }
}
