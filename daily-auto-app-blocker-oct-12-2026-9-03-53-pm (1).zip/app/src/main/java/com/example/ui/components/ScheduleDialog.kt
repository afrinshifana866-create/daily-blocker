package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.AppInfo
import com.example.data.model.BlockSchedule
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ScheduleDialog(
    initialSchedule: BlockSchedule? = null,
    availableApps: List<AppInfo>,
    onDismiss: () -> Unit,
    onSave: (BlockSchedule) -> Unit
) {
    var name by remember { mutableStateOf(initialSchedule?.name ?: "Evening Focus") }
    var startHour by remember { mutableIntStateOf(initialSchedule?.startHour ?: 18) }
    var startMinute by remember { mutableIntStateOf(initialSchedule?.startMinute ?: 0) }
    var endHour by remember { mutableIntStateOf(initialSchedule?.endHour ?: 19) }
    var endMinute by remember { mutableIntStateOf(initialSchedule?.endMinute ?: 0) }

    // Selected days: 1=Mon .. 7=Sun
    var selectedDays by remember {
        mutableStateOf(initialSchedule?.getDaysList()?.toSet() ?: setOf(1, 2, 3, 4, 5, 6, 7))
    }

    // Selected packages
    var selectedPackages by remember {
        mutableStateOf(
            initialSchedule?.getPackageList()?.toSet()
                ?: setOf("com.instagram.android", "com.google.android.youtube")
        )
    }

    var strictMode by remember { mutableStateOf(initialSchedule?.strictMode ?: false) }
    var showAppPicker by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = 680.dp)
                .clip(RoundedCornerShape(24.dp))
                .testTag("schedule_editor_dialog"),
            color = Color(0xFF1E293B)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = if (initialSchedule == null) "Create Daily Schedule" else "Edit Schedule",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Schedule Name input
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Schedule Name") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("schedule_name_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Quick Presets
                Text(
                    text = "Quick Presets",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color(0xFF94A3B8)
                )
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = (startHour == 18 && endHour == 19 && startMinute == 0 && endMinute == 0),
                        onClick = {
                            startHour = 18; startMinute = 0
                            endHour = 19; endMinute = 0
                        },
                        label = { Text("6:00 PM – 7:00 PM (Evening)") },
                        modifier = Modifier.testTag("preset_evening")
                    )
                    FilterChip(
                        selected = (startHour == 9 && endHour == 17 && startMinute == 0 && endMinute == 0),
                        onClick = {
                            startHour = 9; startMinute = 0
                            endHour = 17; endMinute = 0
                        },
                        label = { Text("9:00 AM – 5:00 PM (Work)") }
                    )
                    FilterChip(
                        selected = (startHour == 22 && endHour == 6 && startMinute == 0 && endMinute == 0),
                        onClick = {
                            startHour = 22; startMinute = 0
                            endHour = 6; endMinute = 0
                        },
                        label = { Text("10:00 PM – 6:00 AM (Night)") }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Time Pickers
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Start Time",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFF94A3B8)
                            )
                            Text(
                                text = BlockSchedule.formatTime(startHour, startMinute),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color(0xFF38BDF8)
                            )
                        }
                        Slider(
                            value = (startHour * 60 + startMinute).toFloat(),
                            onValueChange = { total ->
                                val mins = total.toInt()
                                startHour = (mins / 60) % 24
                                startMinute = (mins % 60 / 5) * 5
                            },
                            valueRange = 0f..1435f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFF38BDF8),
                                activeTrackColor = Color(0xFF0284C7)
                            ),
                            modifier = Modifier.testTag("start_time_slider")
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "End Time (Auto-Unlocks)",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFF94A3B8)
                            )
                            Text(
                                text = BlockSchedule.formatTime(endHour, endMinute),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color(0xFFF59E0B)
                            )
                        }
                        Slider(
                            value = (endHour * 60 + endMinute).toFloat(),
                            onValueChange = { total ->
                                val mins = total.toInt()
                                endHour = (mins / 60) % 24
                                endMinute = (mins % 60 / 5) * 5
                            },
                            valueRange = 0f..1435f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFFF59E0B),
                                activeTrackColor = Color(0xFFD97706)
                            ),
                            modifier = Modifier.testTag("end_time_slider")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Repeating Days Selector
                Text(
                    text = "Repeat Automatically",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color(0xFF94A3B8)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val daysMap = listOf(
                        1 to "M", 2 to "T", 3 to "W", 4 to "T", 5 to "F", 6 to "S", 7 to "S"
                    )
                    daysMap.forEach { (dayInt, label) ->
                        val isSelected = selectedDays.contains(dayInt)
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) Color(0xFF0284C7) else Color(0xFF334155))
                                .clickable {
                                    selectedDays = if (isSelected) {
                                        if (selectedDays.size > 1) selectedDays - dayInt else selectedDays
                                    } else {
                                        selectedDays + dayInt
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                color = if (isSelected) Color.White else Color(0xFF94A3B8),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Target Apps to Block
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Blocked Apps (${selectedPackages.size} selected)",
                        style = MaterialTheme.typography.labelLarge,
                        color = Color(0xFF94A3B8)
                    )
                    TextButton(
                        onClick = { showAppPicker = true },
                        modifier = Modifier.testTag("change_apps_button")
                    ) {
                        Text("Add / Change Apps", color = Color(0xFF38BDF8))
                    }
                }

                // Selected Apps Chips
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val allAppsMap = availableApps.associateBy { it.packageName }
                    selectedPackages.forEach { pkg ->
                        val appLabel = allAppsMap[pkg]?.appName ?: pkg.substringAfterLast('.')
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(Color(0xFF334155))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "🔒 $appLabel",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Cancel", color = Color(0xFF94A3B8))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = {
                            val allAppsMap = availableApps.associateBy { it.packageName }
                            val appNames = selectedPackages.map { pkg ->
                                allAppsMap[pkg]?.appName ?: pkg.substringAfterLast('.')
                            }.joinToString(", ")

                            val scheduleToSave = BlockSchedule(
                                id = initialSchedule?.id ?: 0L,
                                name = name.ifBlank { "Daily Focus" },
                                startHour = startHour,
                                startMinute = startMinute,
                                endHour = endHour,
                                endMinute = endMinute,
                                daysOfWeek = selectedDays.sorted().joinToString(","),
                                blockedPackages = selectedPackages.joinToString(","),
                                blockedAppNames = appNames,
                                isEnabled = initialSchedule?.isEnabled ?: true,
                                strictMode = strictMode
                            )
                            onSave(scheduleToSave)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("save_schedule_button")
                    ) {
                        Text("Save Daily Schedule", color = Color.White)
                    }
                }
            }
        }
    }

    // App Picker Sub-dialog
    if (showAppPicker) {
        AppPickerDialog(
            availableApps = availableApps,
            currentlySelected = selectedPackages,
            onDismiss = { showAppPicker = false },
            onConfirm = { updated ->
                selectedPackages = updated
                showAppPicker = false
            }
        )
    }
}

@Composable
fun AppPickerDialog(
    availableApps: List<AppInfo>,
    currentlySelected: Set<String>,
    onDismiss: () -> Unit,
    onConfirm: (Set<String>) -> Unit
) {
    var tempSelected by remember { mutableStateOf(currentlySelected) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 560.dp)
                .clip(RoundedCornerShape(20.dp)),
            color = Color(0xFF1E293B)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Select Apps to Block",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
                Text(
                    text = "Pick the apps you want automatically blocked during this schedule",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF94A3B8)
                )

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(availableApps, key = { it.packageName }) { app ->
                        val isChecked = tempSelected.contains(app.packageName)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isChecked) Color(0xFF0F172A) else Color.Transparent)
                                .clickable {
                                    tempSelected = if (isChecked) {
                                        tempSelected - app.packageName
                                    } else {
                                        tempSelected + app.packageName
                                    }
                                }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { checked ->
                                    tempSelected = if (checked) {
                                        tempSelected + app.packageName
                                    } else {
                                        tempSelected - app.packageName
                                    }
                                },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = Color(0xFF0284C7),
                                    uncheckedColor = Color(0xFF64748B)
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = app.appName,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                                    color = Color.White
                                )
                                Text(
                                    text = app.category + (if (app.isInstalled) " • Installed" else " • Popular"),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(onClick = onDismiss) {
                        Text("Cancel", color = Color(0xFF94A3B8))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onConfirm(tempSelected) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                    ) {
                        Text("Apply (${tempSelected.size})", color = Color.White)
                    }
                }
            }
        }
    }
}
