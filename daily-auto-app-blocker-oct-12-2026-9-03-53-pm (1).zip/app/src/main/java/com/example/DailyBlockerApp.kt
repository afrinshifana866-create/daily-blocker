package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.example.data.repository.ScheduleRepository
import com.example.service.ScheduleAlarmManager
import com.example.service.ScheduleAlarmReceiver

class DailyBlockerApp : Application() {

    override fun onCreate() {
        super.onCreate()

        // 1. Initialize notification channel
        createNotificationChannel()

        // 2. Initialize database and repository cache
        ScheduleRepository.getInstance(this)

        // 3. Ensure all active daily alarms are armed
        ScheduleAlarmManager.rescheduleAll(this)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                ScheduleAlarmReceiver.CHANNEL_ID,
                "Daily App Blocker Status",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Shows active daily blocking schedules and unlock notifications"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }
}
