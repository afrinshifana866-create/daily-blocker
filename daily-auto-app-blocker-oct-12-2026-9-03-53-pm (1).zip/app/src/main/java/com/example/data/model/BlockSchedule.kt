package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Calendar
import java.util.Locale

@Entity(tableName = "block_schedules")
data class BlockSchedule(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val startHour: Int, // 0..23
    val startMinute: Int, // 0..59
    val endHour: Int, // 0..23
    val endMinute: Int, // 0..59
    val daysOfWeek: String = "1,2,3,4,5,6,7", // 1=Mon, 2=Tue, 3=Wed, 4=Thu, 5=Fri, 6=Sat, 7=Sun
    val blockedPackages: String, // Comma separated package names
    val blockedAppNames: String, // Comma separated friendly names
    val isEnabled: Boolean = true,
    val strictMode: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
) {

    fun getPackageList(): List<String> {
        return blockedPackages.split(",")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
    }

    fun getAppNamesList(): List<String> {
        return blockedAppNames.split(",")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
    }

    fun getDaysList(): List<Int> {
        return daysOfWeek.split(",")
            .mapNotNull { it.trim().toIntOrNull() }
    }

    /**
     * Checks if this schedule is currently in its active blocking window.
     */
    fun isCurrentlyActive(cal: Calendar = Calendar.getInstance()): Boolean {
        if (!isEnabled) return false

        // Check day of week: Calendar.DAY_OF_WEEK gives Sunday=1, Monday=2, ..., Saturday=7
        // Convert to ISO-8601: Monday=1, ..., Sunday=7
        val rawDay = cal.get(Calendar.DAY_OF_WEEK)
        val isoDay = when (rawDay) {
            Calendar.SUNDAY -> 7
            Calendar.MONDAY -> 1
            Calendar.TUESDAY -> 2
            Calendar.WEDNESDAY -> 3
            Calendar.THURSDAY -> 4
            Calendar.FRIDAY -> 5
            Calendar.SATURDAY -> 6
            else -> 1
        }

        val activeDays = getDaysList()
        if (activeDays.isNotEmpty() && !activeDays.contains(isoDay)) {
            return false
        }

        val currentHour = cal.get(Calendar.HOUR_OF_DAY)
        val currentMin = cal.get(Calendar.MINUTE)
        val currentTotalMinutes = currentHour * 60 + currentMin

        val startTotalMinutes = startHour * 60 + startMinute
        val endTotalMinutes = endHour * 60 + endMinute

        return if (startTotalMinutes < endTotalMinutes) {
            // Standard daytime window, e.g., 18:00 (6:00 PM) to 19:00 (7:00 PM)
            currentTotalMinutes in startTotalMinutes until endTotalMinutes
        } else if (startTotalMinutes > endTotalMinutes) {
            // Spans midnight, e.g., 22:00 (10:00 PM) to 06:00 (6:00 AM)
            currentTotalMinutes >= startTotalMinutes || currentTotalMinutes < endTotalMinutes
        } else {
            // Equal start and end represents 24h all-day block
            true
        }
    }

    /**
     * Calculates remaining minutes in current block window.
     */
    fun getRemainingMinutes(cal: Calendar = Calendar.getInstance()): Int {
        if (!isCurrentlyActive(cal)) return 0
        val currentTotalMinutes = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val endTotalMinutes = endHour * 60 + endMinute

        return if (currentTotalMinutes < endTotalMinutes) {
            endTotalMinutes - currentTotalMinutes
        } else {
            // Spanning midnight
            (1440 - currentTotalMinutes) + endTotalMinutes
        }
    }

    fun formatTimeRange(): String {
        return "${formatTime(startHour, startMinute)} – ${formatTime(endHour, endMinute)}"
    }

    fun formatDaysSummary(): String {
        val days = getDaysList()
        if (days.size == 7) return "Every day"
        if (days == listOf(1, 2, 3, 4, 5)) return "Weekdays (Mon–Fri)"
        if (days == listOf(6, 7)) return "Weekends (Sat–Sun)"

        val names = mapOf(
            1 to "Mon", 2 to "Tue", 3 to "Wed", 4 to "Thu",
            5 to "Fri", 6 to "Sat", 7 to "Sun"
        )
        return days.mapNotNull { names[it] }.joinToString(", ")
    }

    companion object {
        fun formatTime(hour: Int, minute: Int): String {
            val period = if (hour >= 12) "PM" else "AM"
            val displayHour = when (val h = hour % 12) {
                0 -> 12
                else -> h
            }
            return String.format(Locale.getDefault(), "%d:%02d %s", displayHour, minute, period)
        }
    }
}
