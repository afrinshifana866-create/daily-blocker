package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.BlockSchedule
import kotlinx.coroutines.flow.Flow

@Dao
interface ScheduleDao {

    @Query("SELECT * FROM block_schedules ORDER BY startHour ASC, startMinute ASC")
    fun getAllSchedulesFlow(): Flow<List<BlockSchedule>>

    @Query("SELECT * FROM block_schedules ORDER BY startHour ASC, startMinute ASC")
    suspend fun getAllSchedulesList(): List<BlockSchedule>

    @Query("SELECT * FROM block_schedules WHERE isEnabled = 1")
    suspend fun getActiveSchedulesList(): List<BlockSchedule>

    @Query("SELECT * FROM block_schedules WHERE id = :id")
    suspend fun getScheduleById(id: Long): BlockSchedule?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedule(schedule: BlockSchedule): Long

    @Update
    suspend fun updateSchedule(schedule: BlockSchedule)

    @Delete
    suspend fun deleteSchedule(schedule: BlockSchedule)

    @Query("DELETE FROM block_schedules WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("UPDATE block_schedules SET isEnabled = :isEnabled WHERE id = :id")
    suspend fun setScheduleEnabled(id: Long, isEnabled: Boolean)

    @Query("SELECT COUNT(*) FROM block_schedules")
    suspend fun getScheduleCount(): Int
}
