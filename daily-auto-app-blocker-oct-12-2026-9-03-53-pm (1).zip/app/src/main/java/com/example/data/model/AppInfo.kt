package com.example.data.model

import android.graphics.drawable.Drawable

data class AppInfo(
    val packageName: String,
    val appName: String,
    val icon: Drawable? = null,
    val isInstalled: Boolean = true,
    val category: String = "App",
    val isPreset: Boolean = false
) {
    companion object {
        val PRESET_APPS = listOf(
            AppInfo(
                packageName = "com.instagram.android",
                appName = "Instagram",
                category = "Social",
                isPreset = true
            ),
            AppInfo(
                packageName = "com.google.android.youtube",
                appName = "YouTube",
                category = "Video",
                isPreset = true
            ),
            AppInfo(
                packageName = "com.facebook.katana",
                appName = "Facebook",
                category = "Social",
                isPreset = true
            ),
            AppInfo(
                packageName = "com.zhiliaoapp.musically",
                appName = "TikTok",
                category = "Shorts",
                isPreset = true
            ),
            AppInfo(
                packageName = "com.twitter.android",
                appName = "X (Twitter)",
                category = "Social",
                isPreset = true
            ),
            AppInfo(
                packageName = "com.snapchat.android",
                appName = "Snapchat",
                category = "Social",
                isPreset = true
            ),
            AppInfo(
                packageName = "com.reddit.frontpage",
                appName = "Reddit",
                category = "Forum",
                isPreset = true
            ),
            AppInfo(
                packageName = "com.netflix.mediaclient",
                appName = "Netflix",
                category = "Streaming",
                isPreset = true
            ),
            AppInfo(
                packageName = "com.roblox.client",
                appName = "Roblox",
                category = "Games",
                isPreset = true
            ),
            AppInfo(
                packageName = "com.king.candycrushsaga",
                appName = "Candy Crush",
                category = "Games",
                isPreset = true
            ),
            AppInfo(
                packageName = "tv.twitch.android.app",
                appName = "Twitch",
                category = "Streaming",
                isPreset = true
            )
        )
    }
}
