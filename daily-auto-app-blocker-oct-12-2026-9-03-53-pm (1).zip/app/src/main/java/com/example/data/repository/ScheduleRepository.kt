package com.example.data.repository

import android.content.Context
import com.example.data.db.AppDatabase
import com.example.data.model.BlockSchedule
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.concurrent.CopyOnWriteArrayList

data class BlockResult(
    val schedule: BlockSchedule,
    val remainingMinutes: Int,
    val formattedEndTime: String,
    val blockedPackage: String,
    val blockedAppName: String
)

class ScheduleRepository private constructor(private val context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val dao = db.scheduleDao()
    private val scope = CoroutineScope(Dispatchers.IO)

    // Thread-safe in-memory cache for ultra-fast accessibility inspection (<0.1ms)
    private val schedulesCache = CopyOnWriteArrayList<BlockSchedule>()

    val allSchedules: Flow<List<BlockSchedule>> = dao.getAllSchedulesFlow().onEach { list ->
        schedulesCache.clear()
        schedulesCache.addAll(list)
    }

    init {
        scope.launch {
            val list = dao.getAllSchedulesList()
            schedulesCache.clear()
            schedulesCache.addAll(list)

            // If completely empty, bootstrap initial default matching user's spec:
            // "Save Instagram with a daily schedule of 6:00 PM to 7:00 PM"
            if (list.isEmpty()) {
                val defaultSchedule = BlockSchedule(
                    name = "Evening Focus",
                    startHour = 18,
                    startMinute = 0,
                    endHour = 19,
                    endMinute = 0,
                    daysOfWeek = "1,2,3,4,5,6,7",
                    blockedPackages = "com.instagram.android,com.google.android.youtube,com.facebook.katana",
                    blockedAppNames = "Instagram, YouTube, Facebook",
                    isEnabled = true,
                    strictMode = false
                )
                insertSchedule(defaultSchedule)
            }
        }
    }

    suspend fun insertSchedule(schedule: BlockSchedule): Long {
        val id = dao.insertSchedule(schedule)
        refreshCache()
        return id
    }

    suspend fun updateSchedule(schedule: BlockSchedule) {
        dao.updateSchedule(schedule)
        refreshCache()
    }

    suspend fun deleteSchedule(schedule: BlockSchedule) {
        dao.deleteSchedule(schedule)
        refreshCache()
    }

    suspend fun deleteById(id: Long) {
        dao.deleteById(id)
        refreshCache()
    }

    suspend fun toggleScheduleEnabled(id: Long, isEnabled: Boolean) {
        dao.setScheduleEnabled(id, isEnabled)
        refreshCache()
    }

    private suspend fun refreshCache() {
        val list = dao.getAllSchedulesList()
        schedulesCache.clear()
        schedulesCache.addAll(list)
    }

    /**
     * Fast synchronous check used by Accessibility Service on window change.
     */
    fun isPackageBlockedNow(packageName: String): BlockResult? {
        val now = Calendar.getInstance()
        for (schedule in schedulesCache) {
            if (schedule.isEnabled && schedule.isCurrentlyActive(now)) {
                val packages = schedule.getPackageList()
                if (packages.contains(packageName)) {
                    val appNames = schedule.getAppNamesList()
                    val index = packages.indexOf(packageName)
                    val friendlyName = if (index in appNames.indices) appNames[index] else packageName
                    val remainingMins = schedule.getRemainingMinutes(now)
                    val endFormatted = BlockSchedule.formatTime(schedule.endHour, schedule.endMinute)
                    return BlockResult(
                        schedule = schedule,
                        remainingMinutes = remainingMins,
                        formattedEndTime = endFormatted,
                        blockedPackage = packageName,
                        blockedAppName = friendlyName
                    )
                }
            }
        }
        return null
    }

    /**
     * Finds any schedule that is currently active.
     */
    fun getCurrentlyActiveSchedules(): List<BlockSchedule> {
        val now = Calendar.getInstance()
        return schedulesCache.filter { it.isEnabled && it.isCurrentlyActive(now) }
    }

    companion object {
        @Volatile
        private var INSTANCE: ScheduleRepository? = null

        fun getInstance(context: Context): ScheduleRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = ScheduleRepository(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
