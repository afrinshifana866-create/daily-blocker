package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.example.data.repository.ScheduleRepository
import com.example.ui.AppBlockOverlayActivity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AppBlockAccessibilityService : AccessibilityService() {

    private val repository by lazy { ScheduleRepository.getInstance(this) }
    private var lastBlockedPackage: String? = null
    private var lastBlockedTime: Long = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        _isServiceRunning.value = true
        Log.d(TAG, "Daily Auto App Blocker Accessibility Service connected and active")

        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                    AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
            notificationTimeout = 50
        }
        serviceInfo = info

        // Make sure alarms are armed
        ScheduleAlarmManager.rescheduleAll(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val packageName = event.packageName?.toString() ?: return

        // Ignore our own application package
        if (packageName == packageName || packageName.startsWith("com.example") || packageName.startsWith("com.aistudio.dailyappblocker")) {
            return
        }

        // Ignore standard Android system launcher and system UI navigation
        if (isSystemPackage(packageName)) {
            return
        }

        // Check if this package is blocked by any currently active daily schedule
        val blockResult = repository.isPackageBlockedNow(packageName)
        if (blockResult != null) {
            val now = System.currentTimeMillis()
            val isDebounced = (packageName == lastBlockedPackage && (now - lastBlockedTime) < DEBOUNCE_MS)
            lastBlockedPackage = packageName
            lastBlockedTime = now

            Log.i(TAG, "BLOCKED: $packageName is restricted by schedule '${blockResult.schedule.name}' until ${blockResult.formattedEndTime}")

            // 1. Immediately drop the blocked app to background
            performGlobalAction(GLOBAL_ACTION_HOME)

            // 2. Trigger subtle warning haptic feedback
            vibrateAlert()

            // 3. Show full-screen blocking screen
            if (!isDebounced) {
                val overlayIntent = Intent(this, AppBlockOverlayActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra(AppBlockOverlayActivity.EXTRA_PACKAGE_NAME, blockResult.blockedPackage)
                    putExtra(AppBlockOverlayActivity.EXTRA_APP_NAME, blockResult.blockedAppName)
                    putExtra(AppBlockOverlayActivity.EXTRA_SCHEDULE_NAME, blockResult.schedule.name)
                    putExtra(AppBlockOverlayActivity.EXTRA_SCHEDULE_TIME, blockResult.schedule.formatTimeRange())
                    putExtra(AppBlockOverlayActivity.EXTRA_END_TIME, blockResult.formattedEndTime)
                    putExtra(AppBlockOverlayActivity.EXTRA_REMAINING_MINS, blockResult.remainingMinutes)
                    putExtra(AppBlockOverlayActivity.EXTRA_STRICT_MODE, blockResult.schedule.strictMode)
                    putExtra(AppBlockOverlayActivity.EXTRA_SCHEDULE_ID, blockResult.schedule.id)
                }
                startActivity(overlayIntent)
            }
        }
    }

    private fun isSystemPackage(pkg: String): Boolean {
        return pkg in SYSTEM_IGNORED_PACKAGES ||
                pkg.contains("launcher") ||
                pkg.contains("systemui") ||
                pkg.contains("inputmethod")
    }

    private fun vibrateAlert() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(120)
                }
            }
        } catch (_: Exception) {
            // Ignore if vibration permission or hardware unavailable
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "Accessibility service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        _isServiceRunning.value = false
        Log.d(TAG, "Accessibility service destroyed")
    }

    companion object {
        private const val TAG = "AppBlockerService"
        private const val DEBOUNCE_MS = 1000L

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

        private val SYSTEM_IGNORED_PACKAGES = setOf(
            "com.android.systemui",
            "android",
            "com.google.android.inputmethod.latin",
            "com.android.settings",
            "com.google.android.apps.nexuslauncher",
            "com.android.launcher3",
            "com.sec.android.app.launcher",
            "com.miui.home",
            "com.oppo.launcher",
            "com.huawei.android.launcher"
        )

        /**
         * Checks Android system settings to determine if user has enabled this Accessibility service.
         */
        fun isAccessibilityEnabledInSettings(context: Context): Boolean {
            val expectedServiceName = "${context.packageName}/${AppBlockAccessibilityService::class.java.canonicalName}"
            val enabledServicesSetting = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false

            return enabledServicesSetting.contains(context.packageName) ||
                    enabledServicesSetting.contains(AppBlockAccessibilityService::class.java.simpleName) ||
                    enabledServicesSetting.contains(expectedServiceName)
        }
    }
}
