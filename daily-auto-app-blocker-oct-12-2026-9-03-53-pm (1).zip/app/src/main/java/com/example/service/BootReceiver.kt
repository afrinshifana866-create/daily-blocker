package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.data.repository.ScheduleRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        Log.d("BootReceiver", "Received broadcast action: $action")

        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_LOCKED_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            // Re-arm alarms and refresh schedule state after reboot
            ScheduleAlarmManager.rescheduleAll(context)

            // Warm up ScheduleRepository cache and check currently active schedules
            CoroutineScope(Dispatchers.IO).launch {
                val repository = ScheduleRepository.getInstance(context)
                val activeSchedules = repository.getCurrentlyActiveSchedules()
                Log.d("BootReceiver", "Boot restore complete. Currently active schedules: ${activeSchedules.size}")
            }
        }
    }
}
