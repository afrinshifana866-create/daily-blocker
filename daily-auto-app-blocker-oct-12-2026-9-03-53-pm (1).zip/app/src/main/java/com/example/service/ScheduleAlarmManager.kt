package com.example.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.data.db.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

object ScheduleAlarmManager {

    private const val TAG = "ScheduleAlarmManager"
    const val ACTION_SCHEDULE_START = "com.example.action.SCHEDULE_START"
    const val ACTION_SCHEDULE_END = "com.example.action.SCHEDULE_END"
    const val EXTRA_SCHEDULE_ID = "extra_schedule_id"
    const val EXTRA_SCHEDULE_NAME = "extra_schedule_name"
    const val EXTRA_APPS_COUNT = "extra_apps_count"
    const val EXTRA_END_TIME = "extra_end_time"

    fun rescheduleAll(context: Context) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getInstance(context)
                val activeSchedules = db.scheduleDao().getActiveSchedulesList()
                val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return@launch

                for (schedule in activeSchedules) {
                    scheduleNextAlarm(context, alarmManager, schedule.id, schedule.name, schedule.startHour, schedule.startMinute, isStart = true, schedule.getAppNamesList().size, schedule.formatTimeRange())
                    scheduleNextAlarm(context, alarmManager, schedule.id, schedule.name, schedule.endHour, schedule.endMinute, isStart = false, schedule.getAppNamesList().size, schedule.formatTimeRange())
                }
                Log.d(TAG, "Successfully rescheduled alarms for ${activeSchedules.size} schedules")
            } catch (e: Exception) {
                Log.e(TAG, "Error rescheduling alarms", e)
            }
        }
    }

    private fun scheduleNextAlarm(
        context: Context,
        alarmManager: AlarmManager,
        scheduleId: Long,
        scheduleName: String,
        hour: Int,
        minute: Int,
        isStart: Boolean,
        appsCount: Int,
        timeRangeFormatted: String
    ) {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        // If time already passed today, schedule for tomorrow
        if (target.before(now)) {
            target.add(Calendar.DAY_OF_YEAR, 1)
        }

        val action = if (isStart) ACTION_SCHEDULE_START else ACTION_SCHEDULE_END
        val requestCode = (scheduleId * 10 + (if (isStart) 1 else 2)).toInt()

        val intent = Intent(context, ScheduleAlarmReceiver::class.java).apply {
            this.action = action
            putExtra(EXTRA_SCHEDULE_ID, scheduleId)
            putExtra(EXTRA_SCHEDULE_NAME, scheduleName)
            putExtra(EXTRA_APPS_COUNT, appsCount)
            putExtra(EXTRA_END_TIME, timeRangeFormatted)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        target.timeInMillis,
                        pendingIntent
                    )
                } else {
                    alarmManager.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        target.timeInMillis,
                        pendingIntent
                    )
                }
            } else {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    target.timeInMillis,
                    pendingIntent
                )
            }
        } catch (e: SecurityException) {
            Log.w(TAG, "Cannot schedule exact alarm: ${e.message}")
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                target.timeInMillis,
                pendingIntent
            )
        }
    }
}
