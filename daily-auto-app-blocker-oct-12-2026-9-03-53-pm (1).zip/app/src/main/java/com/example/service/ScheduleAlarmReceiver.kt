package com.example.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R

class ScheduleAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val scheduleName = intent.getStringExtra(ScheduleAlarmManager.EXTRA_SCHEDULE_NAME) ?: "Daily Focus"
        val scheduleId = intent.getLongExtra(ScheduleAlarmManager.EXTRA_SCHEDULE_ID, -1L)
        val timeRange = intent.getStringExtra(ScheduleAlarmManager.EXTRA_END_TIME) ?: ""

        createNotificationChannel(context)

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notificationId = 1000 + (scheduleId % 1000).toInt()

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        when (action) {
            ScheduleAlarmManager.ACTION_SCHEDULE_START -> {
                val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_lock_lock)
                    .setContentTitle("🔒 $scheduleName Active")
                    .setContentText("Selected apps are now blocked ($timeRange)")
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setOngoing(true)
                    .setContentIntent(pendingIntent)
                    .setAutoCancel(false)
                    .build()

                notificationManager.notify(notificationId, notification)
            }
            ScheduleAlarmManager.ACTION_SCHEDULE_END -> {
                notificationManager.cancel(notificationId)

                // Brief celebratory completion notification
                val unblockNotification = NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                    .setContentTitle("✨ Schedule Completed")
                    .setContentText("$scheduleName has ended. Your apps are now accessible.")
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setContentIntent(pendingIntent)
                    .setAutoCancel(true)
                    .build()

                notificationManager.notify(notificationId + 5000, unblockNotification)
            }
        }

        // Prime the recurrence for the following day
        ScheduleAlarmManager.rescheduleAll(context)
    }

    private fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Daily App Blocker Status"
            val descriptionText = "Notifications for active app blocking schedules"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "daily_app_blocker_channel"
    }
}
