package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppInfo
import com.example.data.model.BlockSchedule
import com.example.ui.AppBlockOverlayActivity
import com.example.ui.MainViewModel
import com.example.ui.components.ScheduleDialog
import com.example.ui.screens.AppSelectorScreen
import com.example.ui.screens.DiagnosticsScreen
import com.example.ui.screens.HelpScreen
import com.example.ui.screens.SchedulesScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh permissions status when returning from System Settings
        viewModel.refreshDiagnostics()
    }
}

enum class NavigationTab(val label: String) {
    SCHEDULES("Schedules"),
    APPS("Apps"),
    DIAGNOSTICS("Diagnostics"),
    HELP("Help")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(viewModel: MainViewModel) {
    var selectedTab by remember { mutableStateOf(NavigationTab.SCHEDULES) }
    var editingSchedule by remember { mutableStateOf<BlockSchedule?>(null) }
    var showScheduleDialog by remember { mutableStateOf(false) }

    val schedules by viewModel.schedules.collectAsStateWithLifecycle()
    val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()
    val diagnostics by viewModel.diagnostics.collectAsStateWithLifecycle()
    val activeSchedule by viewModel.activeSchedule.collectAsStateWithLifecycle()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = Color(0xFF0F172A),
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(if (diagnostics.isAccessibilityEnabled) Color(0xFF10B981) else Color(0xFFF59E0B))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Daily Auto App Blocker",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            ),
                            color = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color(0xFF0F172A)
                ),
                modifier = Modifier.testTag("main_top_app_bar")
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF1E293B),
                contentColor = Color.White,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                NavigationBarItem(
                    selected = selectedTab == NavigationTab.SCHEDULES,
                    onClick = { selectedTab = NavigationTab.SCHEDULES },
                    icon = { Icon(Icons.Default.Schedule, contentDescription = "Schedules") },
                    label = { Text("Schedules") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = Color(0xFF38BDF8),
                        indicatorColor = Color(0xFF0284C7),
                        unselectedIconColor = Color(0xFF94A3B8),
                        unselectedTextColor = Color(0xFF94A3B8)
                    ),
                    modifier = Modifier.testTag("nav_tab_schedules")
                )
                NavigationBarItem(
                    selected = selectedTab == NavigationTab.APPS,
                    onClick = { selectedTab = NavigationTab.APPS },
                    icon = { Icon(Icons.Default.Apps, contentDescription = "Apps") },
                    label = { Text("Apps") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = Color(0xFF38BDF8),
                        indicatorColor = Color(0xFF0284C7),
                        unselectedIconColor = Color(0xFF94A3B8),
                        unselectedTextColor = Color(0xFF94A3B8)
                    ),
                    modifier = Modifier.testTag("nav_tab_apps")
                )
                NavigationBarItem(
                    selected = selectedTab == NavigationTab.DIAGNOSTICS,
                    onClick = { selectedTab = NavigationTab.DIAGNOSTICS },
                    icon = { Icon(Icons.Default.Security, contentDescription = "Status") },
                    label = { Text("Status") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = Color(0xFF38BDF8),
                        indicatorColor = Color(0xFF0284C7),
                        unselectedIconColor = Color(0xFF94A3B8),
                        unselectedTextColor = Color(0xFF94A3B8)
                    ),
                    modifier = Modifier.testTag("nav_tab_status")
                )
                NavigationBarItem(
                    selected = selectedTab == NavigationTab.HELP,
                    onClick = { selectedTab = NavigationTab.HELP },
                    icon = { Icon(Icons.Default.HelpOutline, contentDescription = "Help") },
                    label = { Text("Help") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = Color(0xFF38BDF8),
                        indicatorColor = Color(0xFF0284C7),
                        unselectedIconColor = Color(0xFF94A3B8),
                        unselectedTextColor = Color(0xFF94A3B8)
                    ),
                    modifier = Modifier.testTag("nav_tab_help")
                )
            }
        }
    ) { innerPadding ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            color = Color(0xFF0F172A)
        ) {
            when (selectedTab) {
                NavigationTab.SCHEDULES -> {
                    SchedulesScreen(
                        schedules = schedules,
                        diagnostics = diagnostics,
                        activeSchedule = activeSchedule,
                        onToggleSchedule = { id, isEnabled -> viewModel.toggleSchedule(id, isEnabled) },
                        onEditSchedule = { schedule ->
                            editingSchedule = schedule
                            showScheduleDialog = true
                        },
                        onDeleteSchedule = { id -> viewModel.deleteSchedule(id) },
                        onCreateSchedule = {
                            editingSchedule = null
                            showScheduleDialog = true
                        },
                        onTestSchedule = { schedule ->
                            viewModel.createInstantTestSchedule(
                                targetPackage = schedule.getPackageList().firstOrNull() ?: "com.instagram.android",
                                targetAppName = schedule.getAppNamesList().firstOrNull() ?: "Instagram"
                            )
                        }
                    )
                }

                NavigationTab.APPS -> {
                    AppSelectorScreen(
                        apps = installedApps,
                        schedules = schedules,
                        onCreateScheduleWithApps = { selectedAppList ->
                            val defaultPkgs = selectedAppList.joinToString(",") { it.packageName }
                            val defaultLabels = selectedAppList.joinToString(", ") { it.appName }
                            editingSchedule = BlockSchedule(
                                name = "Focus Time",
                                startHour = 18,
                                startMinute = 0,
                                endHour = 19,
                                endMinute = 0,
                                blockedPackages = defaultPkgs,
                                blockedAppNames = defaultLabels
                            )
                            showScheduleDialog = true
                        }
                    )
                }

                NavigationTab.DIAGNOSTICS -> {
                    DiagnosticsScreen(
                        diagnostics = diagnostics,
                        onRefresh = { viewModel.refreshDiagnostics() },
                        onCreateTestSchedule = {
                            viewModel.createInstantTestSchedule()
                        }
                    )
                }

                NavigationTab.HELP -> {
                    HelpScreen()
                }
            }
        }
    }

    if (showScheduleDialog) {
        ScheduleDialog(
            initialSchedule = editingSchedule,
            availableApps = installedApps,
            onDismiss = { showScheduleDialog = false },
            onSave = { scheduleToSave ->
                viewModel.saveSchedule(scheduleToSave)
                showScheduleDialog = false
            }
        )
    }
}
