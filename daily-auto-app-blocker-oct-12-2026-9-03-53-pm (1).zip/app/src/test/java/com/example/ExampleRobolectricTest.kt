package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.BlockSchedule
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.Calendar

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Daily Auto App Blocker", appName)
    }

    @Test
    fun `schedule active check between 6 PM and 7 PM`() {
        val schedule = BlockSchedule(
            name = "Evening Focus",
            startHour = 18,
            startMinute = 0,
            endHour = 19,
            endMinute = 0,
            daysOfWeek = "1,2,3,4,5,6,7",
            blockedPackages = "com.instagram.android",
            blockedAppNames = "Instagram",
            isEnabled = true
        )

        // Test at 6:30 PM (18:30)
        val cal630 = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 18)
            set(Calendar.MINUTE, 30)
            set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        }
        assertTrue("Instagram should be blocked at 6:30 PM", schedule.isCurrentlyActive(cal630))

        // Test at 7:00 PM (19:00 - should be unlocked)
        val cal700 = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 19)
            set(Calendar.MINUTE, 0)
            set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        }
        assertFalse("Instagram should become accessible at 7:00 PM", schedule.isCurrentlyActive(cal700))

        // Test at 5:59 PM (17:59 - should not yet be blocked)
        val cal559 = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 17)
            set(Calendar.MINUTE, 59)
            set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        }
        assertFalse("Instagram should not be blocked at 5:59 PM", schedule.isCurrentlyActive(cal559))
    }

    @Test
    fun `schedule formatting helpers`() {
        assertEquals("6:00 PM", BlockSchedule.formatTime(18, 0))
        assertEquals("7:00 PM", BlockSchedule.formatTime(19, 0))
        assertEquals("12:00 AM", BlockSchedule.formatTime(0, 0))
        assertEquals("12:00 PM", BlockSchedule.formatTime(12, 0))

        val schedule = BlockSchedule(
            name = "Test",
            startHour = 18,
            startMinute = 0,
            endHour = 19,
            endMinute = 0,
            blockedPackages = "com.instagram.android,com.google.android.youtube",
            blockedAppNames = "Instagram, YouTube"
        )
        assertEquals("6:00 PM – 7:00 PM", schedule.formatTimeRange())
        assertEquals(listOf("com.instagram.android", "com.google.android.youtube"), schedule.getPackageList())
    }
}
